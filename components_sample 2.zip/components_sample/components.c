#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "dc_image.h"



#define MIN(a,b)  ( (a) < (b) ? (a) : (b) )
#define MAX(a,b)  ( (a) > (b) ? (a) : (b) )
#define ABS(x)    ( (x) <= 0 ? 0-(x) : (x) )


//--------------------------------------------------
//--------------------------------------------------
// You must modify this disjoint set implementation
//--------------------------------------------------
//--------------------------------------------------


typedef struct DisjointSet {
	int r,g,b;
	int x,y;
	int rank;
	struct DisjointSet *parent;
} DisjointSet;

double Gaussian_formula(double distance, double sigma) //x is root of x-xi squred + y-yi squared 
{ 
	double val= distance/sigma;
	double val_2 = 1/(sqrt(2*M_PI*pow (sigma,2.0)));
	double e_power = exp(-0.5*pow(val,2));
	double final_val = val_2 * e_power;
	return final_val;
}

DisjointSet **malloc2di(int rows, int cols) {
	int y;
	DisjointSet **ptr = (DisjointSet**)malloc(rows*sizeof(DisjointSet*));
	for (y=0; y<rows; y++)
		ptr[y] = (DisjointSet*)calloc(cols,sizeof(DisjointSet));
	return ptr;
}

DisjointSet *DisjointSetFindRoot(DisjointSet *current)
{
	//if(curr == NULL){return NULL;}
	// Add code here
	
	if (current -> parent != current){
		current -> parent = DisjointSetFindRoot(current -> parent);
	
	}
	return current -> parent;
	
}

void DisjointSetUnion(DisjointSet *d_set1, DisjointSet *d_set2)
{
	// Add code here

	DisjointSet *p1= DisjointSetFindRoot(d_set1);
	DisjointSet *p2= DisjointSetFindRoot(d_set2);

		if(p1->rank < p2->rank)
	{
		p1-> parent = p2->parent;
		p1->b= p2->b;
		p1->r=p2->r;
		p1->g=p2->g;
		//p1->rank = p1->rank +1;

	}
	else{
		if(p1->rank>p2->rank){

		p2-> parent = p1->parent;
		p2->b= p1->b;
		p2->r=p1->r;
		p2->g=p1->g;
		//p2->rank = p2->rank +1;

		
	}
	if(p1->rank == p2->rank){
		p1->rank = p1->rank +1;

	}

	}
}






//--------------------------------------------------
//--------------------------------------------------
// The following "run" function runs the entire algorithm
//  for a single vision file
//--------------------------------------------------
//--------------------------------------------------

void run(const char *infile, const char *outpre, int canny_thresh, int canny_blur)
{
	int y,x,i,j;
	int rows, cols, chan;

	//-----------------
	// Read the image    [y][x][c]   y number rows   x cols  c 3
	//-----------------
	byte ***img = LoadRgb(infile, &rows, &cols, &chan);
	printf("img %p rows %d cols %d chan %d\n", img, rows, cols, chan);

	char str[4096];
	sprintf(str, "out/%s_1_img.png", outpre);
	SaveRgbPng(img, str, rows, cols);
	
	//-----------------
	// Convert to Grayscale
	//-----------------
	byte **gray = malloc2d(rows, cols);
	for (y=0; y<rows; y++){
		for (x=0; x<cols; x++) {
			int r = img[y][x][0];   // red
			int g = img[y][x][1];   // green
			int b = img[y][x][2];   // blue
			gray[y][x] =  (r+g+b) / 3;
		}
	}

	sprintf(str, "out/%s_2_gray.png", outpre);
	SaveGrayPng(gray, str, rows, cols);

	//-----------------
	// Box Blur   ToDo: Gaussian Blur is better
	//-----------------
	
	// Box blur is separable, so separately blur x and y
	int k_x=canny_blur, k_y=canny_blur;
	
	// blur in the x dimension
	byte **blurx = (byte**)malloc2d(rows, cols);
	for (y=0; y<rows; y++) {
		for (x=0; x<cols; x++) {
			
			// Start and end to blur
			int minx = x-k_x/2;      // k_x/2 left of pixel
			int maxx = minx + k_x;   // k_x/2 right of pixel
			minx = MAX(minx, 0);     // keep in bounds
			maxx = MIN(maxx, cols);
			
			// average blur it
			int x2;
			int total = 0;
			int count = 0;
			for (x2=minx; x2<maxx; x2++) {
				total += gray[y][x2];    // use "gray" as input
				count++;
			}
			blurx[y][x] = total / count; // blurx is output
		}
	}
	
	sprintf(str, "out/%s_3_blur_just_x.png", outpre);
	SaveGrayPng(blurx, str, rows, cols);
	
	// blur in the y dimension
	byte **blur = (byte**)malloc2d(rows, cols);
	for (y=0; y<rows; y++) {
		for (x=0; x<cols; x++) {
			
			// Start and end to blur
			int miny = y-k_y/2;      // k_x/2 left of pixel
			int maxy = miny + k_y;   // k_x/2 right of pixel
			miny = MAX(miny, 0);     // keep in bounds
			maxy = MIN(maxy, rows);
			
			// average blur it
			int y2;
			int total = 0;
			int count = 0;
			for (y2=miny; y2<maxy; y2++) {
				total += blurx[y2][x];    // use blurx as input
				count++;
			}
			blur[y][x] = total / count;   // blur is output
		}
	}
	
	sprintf(str, "out/%s_3_blur.png", outpre);
	SaveGrayPng(blur, str, rows, cols);
	
	
	//-----------------
	// Take the "Sobel" (magnitude of derivative)
	//  (Actually we'll make up something similar)
	//-----------------
	
	byte **sobel = (byte**)malloc2d(rows, cols);
	
	for (y=0; y<rows; y++) {
		for (x=0; x<cols; x++) {
			int mag=0;
			
			if (y>0)      mag += ABS((int)blur[y-1][x] - (int)blur[y][x]);
			if (x>0)      mag += ABS((int)blur[y][x-1] - (int)blur[y][x]);
			if (y<rows-1) mag += ABS((int)blur[y+1][x] - (int)blur[y][x]);
			if (x<cols-1) mag += ABS((int)blur[y][x+1] - (int)blur[y][x]);
			
			int out = 3*mag;
			sobel[y][x] = MIN(out,255);
		}
	}
	
	
	sprintf(str, "out/%s_4_sobel.png", outpre);
	SaveGrayPng(sobel, str, rows, cols);
	
	//-----------------
	// Non-max suppression
	//-----------------
	byte **nonmax = malloc2d(rows, cols);    // note: *this* initializes to zero!
	
	for (y=1; y<rows-1; y++)
	{
		for (x=1; x<cols-1; x++)
		{
			// Is it a local maximum
			int is_y_max = (sobel[y][x] > sobel[y-1][x] && sobel[y][x]>=sobel[y+1][x]);
			int is_x_max = (sobel[y][x] > sobel[y][x-1] && sobel[y][x]>=sobel[y][x+1]);
			if (is_y_max || is_x_max)
				nonmax[y][x] = sobel[y][x];
			else
				nonmax[y][x] = 0;
		}
	}
	
	sprintf(str, "out/%s_5_nonmax.png", outpre);
	SaveGrayPng(nonmax, str, rows, cols);
	
	//-----------------
	// Final Threshold
	//-----------------
	byte **edges = malloc2d(rows, cols);    // note: *this* initializes to zero!
	
	for (y=0; y<rows; y++) {
		for (x=0; x<cols; x++) {
			if (nonmax[y][x] > canny_thresh){
				edges[y][x] = 255;
				//printf("%d\n", edges[y][x]);
			}
		
			else
			{
				edges[y][x] = 0;
				
		}
		}
		
	}

		
	sprintf(str, "out/%s_6_edges.png", outpre);
	//printf("hello");
	SaveGrayPng(edges, str, rows, cols);

  DisjointSet **array_disjoint= malloc2di(rows,cols);
  for(int i =0; i<rows;i++){
		//array_disjoint[i]=(DisjointSet*)malloc(cols*sizeof(DisjointSet*));
		for (int j=0;j<cols;j++){
			
		  array_disjoint[i][j].r=0;
		  array_disjoint[i][j].g=0;
		  array_disjoint[i][j].b=0;
		  array_disjoint[i][j].rank=0;
		  array_disjoint[i][j].x=i;
		  array_disjoint[i][j].y=j;
		  array_disjoint[i][j].parent= &(array_disjoint[i][j]);
		  				
		}
		}
	
	
	// forming connected components

int threshold=10;
int kernel_size=7;
int xi=0;int yi=0;
byte ***coloring= malloc3d(rows,cols,3);
//printf("%d\n",coloring[1][2][0]);
//printf("hi colors");
srand(0);
for(int k=0; k<rows-kernel_size ; k++){
		//	printf("%d\n",k);
		for(int l=0; l<cols-kernel_size; l++){           
	        int row_size = k + kernel_size;
			int col_size = l + kernel_size;
			
			// calculate midpoint
			int x_mid = (row_size+k-1)/2;
			int y_mid = (col_size+l-1)/2;
			//printf("%d\n",l);
			// check value of midpoints =255
		
			if(edges[x_mid][y_mid]==255){
						//printf("%d\n",coloring[x_mid][y_mid][0]);
                if(coloring[x_mid][y_mid][0] == 0 && coloring[x_mid][y_mid][1] == 0 && coloring[x_mid][y_mid][2] == 0){
				array_disjoint[x_mid][y_mid].r = rand() % 255 ;
				//printf("%d\n",array_disjoint[x_mid][y_mid].r);
				array_disjoint[x_mid][y_mid].g= rand() % 255 ;
				array_disjoint[x_mid][y_mid].b = rand() % 255 ;

				}
				
				else{
                    //printf("in parent");
					DisjointSet *_parent = DisjointSetFindRoot(&(array_disjoint[x_mid][y_mid]));
					//printf("%d\n",_parent->r );
					array_disjoint[x_mid][y_mid].r = _parent->r;
				//printf("%d\n",array_disjoint[x_mid][y_mid].r);
				array_disjoint[x_mid][y_mid].g= _parent->g;
				array_disjoint[x_mid][y_mid].b = _parent->b;
				array_disjoint[x_mid][y_mid].rank = _parent->rank;
				array_disjoint[x_mid][y_mid].parent = _parent;
				}
			//	printf("hi");
                // copy the colors
				//  
			
			for(xi=0; xi<row_size; xi++){
				
					for(yi=0; yi<col_size;yi++){
						// check the value of current pixel as 255
						//printf("hello world");
						if(edges[xi][yi] == 255){
								//printf("testing2");
								int distance = (int)(pow((double)(x_mid-xi),(double)2) + pow((double)(y_mid-yi),(double)2));
								//printf("%d\n",distance);
								distance = (int)sqrt(distance);
							
							if(distance != 0 && distance <= threshold){
								//connecting components
								//printf("testing3");
								DisjointSetUnion(&array_disjoint[x_mid][y_mid],&array_disjoint[xi][yi]);
								
								
							}
						}
					}
			}
			
		
		// for(int new1=0;new1<row_size;new1++){
		// 	for (int new2=0;new2<col_size;new2++){
				

        //                         if(edges[new1][new2] == 255){
		// 						//printf("testing2");
		// 						int distance = (int)(pow((double)(x_mid-new1),(double)2) + pow((double)(y_mid-new2),(double)2));
		// 						//printf("%d\n",distance);
		// 						distance = (int)sqrt(distance);
							
		// 					if(distance != 0 && distance <= threshold){
								
		// 						coloring[new1][new2][0] = array_disjoint[x_mid][y_mid].r;
		// 						coloring[new1][new2][1] = array_disjoint[x_mid][y_mid].g;
		// 						coloring[new1][new2][2] = array_disjoint[x_mid][y_mid].b;
		// 					}
			}
		}
			}
		

		for(int new1=0;new1<rows;new1++){
			for (int new2=0;new2<cols;new2++){
				

                               
								DisjointSet *root = DisjointSetFindRoot(&array_disjoint[new1][new2]) ;

								coloring[new1][new2][0] = root->r;
								coloring[new1][new2][1] = root->g;
								coloring[new1][new2][2] = root->b;
							}
		}





sprintf(str, "out/%s_7_color.png", outpre);
	SaveRgbPng(coloring,str,rows,cols);



// gaussian blurring 


for(int i_new=0; i_new<rows;i_new++){
for(int y_new=0;y_new<cols;y_new++){

double sum_i=0;
double sum_y=0;
double sum_gauss=0;
if(edges[i_new][y_new]!=0){
	
	DisjointSet *pa = DisjointSetFindRoot(&array_disjoint[i_new][y_new]);

for(int p=0; p<rows; p++){
for(int q=0; q<cols; q++){
	DisjointSet *_pa = DisjointSetFindRoot(&array_disjoint[p][q]);
	if (pa ==_pa && p!=i_new && y_new!=q){
double distForm =((double)(pow((double)(i_new-p),(double)2) + pow((double)(y_new-q),(double)2)));
//printf("%d\n",distForm);
double g_val= Gaussian_formula(distForm,100.1);
sum_i= (sum_i)+(g_val*p);
sum_y =(sum_y)+(g_val*q);
sum_gauss= sum_gauss+g_val;
//printf("%d\n",sum_i);
//printf("%d\n",sum_y);
//printf("%f\n",g_val);

}
}

}

//////printf("%d\n",sum_i);
//printf("%d\n",sum_y);
//printf("%f\n",sum_gauss);
    int new_x= (int)floor(sum_i/sum_gauss);
    int new_y = (int)floor(sum_y/sum_gauss);
    
	//printf("%f%f\n",sum_i/sum_gauss,sum_y/sum_gauss);
	coloring[new_x][new_y][0] = 255;
	coloring[new_x][new_y][1] = 255;
	coloring[new_x][new_y][2] = 255;

	}
}
}
sprintf(str, "out/%s_8_color.png", outpre);
SaveRgbPng(coloring,str,rows,cols);

 }
 

int main()
{
	system("mkdir out");
	
	run("puppy.jpg", "puppy", 45, 25);
	run("pentagon.png", "pentagon", 45, 10);
	run("tiger.jpg", "tiger", 45, 10);
	run("houses.jpg", "houses", 45, 10);
	
	printf("Done!\n");
}


